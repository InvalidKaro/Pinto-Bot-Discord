import asyncio
import discord
from discord.ext import commands
import random
import time
from discord \
    import Member, Guild, User
import datetime
from datetime import datetime
from datetime import date
import configparser
import os, os.path
import json
from discord.ext.commands import *
from discord.voice_client import VoiceClient
from discord.utils import get
import youtube_dl
import pytz
import sys
from discord.ext import tasks
import requests
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter
import sys
import re
import PIL
from io import BytesIO
import urllib3
import urllib.request
import mysql
import re
from mysql import connector
from operator import pow, truediv, mul, add, sub
import aiohttp
import shlex
from discord import Intents
import math
import random
from random import randint

operators = {
    '+': add,
    '-': sub,
    '*': mul,
    '/': truediv,
    ':': truediv

}
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from xml.etree import cElementTree
from packages.all import * 
from packages.p_mysql import *


intent = Intents().all()
client = commands.Bot(command_prefix = ["p!",'P!', '<@809824051773177917>'], 
                      case_insensitive=True, 
                      intents = intent)
client.remove_command("help")



class SERVER(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command
    async def help_regeln(self,ctx):
        embed = discord.Embed(color=0xffc585)
        await ctx.send(embed=embed)


    @commands.command()
    async def regeln(self, ctx):
        embed = discord.Embed(color=0xffc585)
        embed.set_author(name=f"REGELWERK VON '{ctx.guild.name}'")
        embed.set_thumbnail(url=f"{ctx.guild.icon_url}")
        embed.add_field(name="REGEL §1", 
                        value="<:pfeil:802700214318137344>| 1. Das Provozieren oder absichtliche Nerven in Text- sowie Sprachform, wird nicht geduldet.", 
                        inline=False)
        embed.add_field(name="REGEL §2", 
                        value="<:pfeil:802700214318137344>| 2. Beleidigende, Rassistische, Homophobe oder allgemein menschenverachtende Aussagen, werden bestraft.", 
                        inline=False)
        embed.add_field(name="REGEL §3", 
                        value="<:pfeil:802700214318137344>| 3. Nicht-jugendfreier Inhalt wird nicht geduldet und konsequent bestraft.", 
                        inline=False)
        embed.add_field(name="REGEL §4", 
                        value=f"<:pfeil:802700214318137344>| 4. Deutsch ist die Hauptsprache auf **{ctx.guild.name}**!", 
                        inline=False)
        embed.add_field(name="REGEL §5", 
                        value=f"<:pfeil:802700214318137344>| 5. Werbung in Text-, Sprachform oder im privaten Chat wird nicht gestattet.", 
                        inline=False)
        embed.add_field(name="Kurzfassung:", 
                        value=f"<:pfeil:802700214318137344>| Verhalte dich so, dass sich jeder auf dem Server wohlfühlen kann.", 
                        inline=False)
        embed.set_footer(text=f"Bei Fragen wende dich an ein Teammitglied")
        await ctx.send(embed=embed)

    @commands.command()
    async def d23regeln(self, ctx):
        embed = discord.Embed(color=0xffc585)
        embed.set_author(name=f"REGELWERK VON '{ctx.guild.name}'")
        embed.set_thumbnail(url=f"{ctx.guild.icon_url}")
        embed.add_field(name="REGEL §1", 
                        value="<:pfeil:802700214318137344>| 1. Das Provozieren oder absichtliche Nerven in Text- sowie Sprachform, wird nicht geduldet.", 
                        inline=False)
        embed.add_field(name="REGEL §2", 
                        value="<:pfeil:802700214318137344>| 2. Beleidigende, Rassistische, Homophobe oder allgemein menschenverachtende Aussagen, werden bestraft.", 
                        inline=False)
        embed.add_field(name="REGEL §3", 
                        value="<:pfeil:802700214318137344>| 3. Halte dich bitte an die Discord TOS.", 
                        inline=False)
        embed.add_field(name="REGEL §4", 
                        value=f"<:pfeil:802700214318137344>| 4. Deutsch ist die Hauptsprache auf **{ctx.guild.name}**!", 
                        inline=False)
        embed.add_field(name="REGEL §5", 
                        value=f"<:pfeil:802700214318137344>| 5. Werbung in Text-, Sprachform oder im privaten Chat wird nicht gestattet.", 
                        inline=False)
        embed.add_field(name="Kurzfassung:", 
                        value=f"<:pfeil:802700214318137344>| Verhalte dich so, dass sich jeder auf dem Server wohlfühlen kann.", 
                        inline=False)
        embed.set_footer(text=f"Bei Fragen wende dich an ein Teammitglied")
        await ctx.send(embed=embed)

    @commands.command()
    async def devapp(self, ctx):
        if ctx.author.id == 792839933387472918:
            embed=discord.Embed(color=0xffc585)
            embed.set_author(name='Application Developer',
                            icon_url='https://www.cpp.edu/admissions/img/icons/checklist_icon_green.png')
            embed.set_footer(text=f'{ctx.guild.name}',
                            icon_url='https://cdn.discordapp.com/avatars/809824051773177917/8e99a15c95bf998f1cb79e26c95804f0.png')
            embed.set_thumbnail(url=f'{ctx.guild.icon_url}')
            embed.add_field(name='Anforderungen:',
                            value='> -mind. 1 Jahr Erfahrung in Python\r\n > -mind. 2 eigene Bots\r\n > -Im Chat aktiv\r\n > -Ein eigener Computer',
                            inline=False)
            embed.add_field(name='Zusatzinfos:',
                            value='> -Deine Onlinezeiten\r\n > -Dein Alter\r\n > -Dein Name\r\n > -Warum möchtest du Dev bei uns werden?',
                            inline=False)
            await ctx.send(embed=embed)
    @commands.command()
    async def supapp(self, ctx):
        if ctx.author.id == 792839933387472918:
            embed=discord.Embed(color=0xffc585)
            embed.set_author(name='Application Supporter',
                            icon_url='https://www.cpp.edu/admissions/img/icons/checklist_icon_green.png')
            embed.set_footer(text=f'{ctx.guild.name}',
                            icon_url='https://cdn.discordapp.com/avatars/809824051773177917/8e99a15c95bf998f1cb79e26c95804f0.png')
            embed.set_thumbnail(url=f'{ctx.guild.icon_url}')
            embed.add_field(name='Anforderungen:',
                            value='> -mind. 4 Monate auf Discord\r\n > -Bereits bestehende Erfahrung\r\n > -Im Chat aktiv\r\n > -Geistige Reife',
                            inline=False)
            embed.add_field(name='Zusatzinfos:',
                            value='> -Deine Onlinezeiten\r\n > -Dein Alter\r\n > -Dein Name\r\n > -Warum möchtest du Supporter bei uns werden?',
                            inline=False)
            await ctx.send(embed=embed)
    @commands.command()
    async def desapp(self, ctx):
        if ctx.author.id == 792839933387472918:
            embed=discord.Embed(color=0xffc585)
            embed.set_author(name='Application Designer',
                            icon_url='https://www.cpp.edu/admissions/img/icons/checklist_icon_green.png')
            embed.set_footer(text=f'{ctx.guild.name}',
                            icon_url='https://cdn.discordapp.com/avatars/809824051773177917/8e99a15c95bf998f1cb79e26c95804f0.png')
            embed.set_thumbnail(url=f'{ctx.guild.icon_url}')
            embed.add_field(name='Anforderungen:',
                            value='> -mind. 4 Monate auf Discord\r\n > -Vorlage bereitstellen \r\n > -Im Chat aktiv\r\n > -Erfahrung mit Photoshop, etc',
                            inline=False)
            embed.add_field(name='Zusatzinfos:',
                            value='> -Deine Onlinezeiten\r\n > -Dein Alter\r\n > -Dein Name\r\n > -Warum möchtest du Designer bei uns werden?',
                            inline=False)
            await ctx.send(embed=embed)
    @commands.command()
    async def faq(self,ctx):
        embed = discord.Embed(color=0xffc585)
        embed.add_field(name='FAQ Pinto', value='**Was ist Pintos Prefix?**\r\n > -> Das Prefix für Pinto ist `p!`\r\n \r\n **Wie kann ich Pinto meinem Server hinzufügen?**\r\n > -> Nutze hierfür `p!invite`\r\n \r\n **Was kann Pinto?**\r\n > -> Benutze hierfür `p!help`\r\n \r\n **Wie aktiviere ich den Disboard Counter richtig?**\r\n > -> Vorerst ist diese Funktion nicht aktiviert\r\n')
        embed.set_footer(text=f'{ctx.guild.name}',
                        icon_url='https://cdn.discordapp.com/avatars/809824051773177917/8e99a15c95bf998f1cb79e26c95804f0.png')
        embed.add_field(name='FAQ Allgemein', value='**Wie bekomme ich eine UserID?**\r\n > -> Aktiviere den Entwicklermodus und Rechtsklicke einen User\r\n \r\n **Wie erstelle ich einen guten Server?**\r\n > -> Erstelle einfach ein Ticket ich erkläre es ;)', inline=False)
        embed.set_thumbnail(url=f'{ctx.guild.icon_url}')
        await ctx.send(embed=embed)
        await ctx.message.delete()
        

def setup(client):
    client.add_cog(SERVER(client))