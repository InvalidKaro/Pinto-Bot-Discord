import asyncio
import configparser
import datetime
import json
import math
import os
import os.path
import random
import re
import shlex
import sys
import time
import urllib.request
from datetime import date, datetime
from io import BytesIO
from operator import add, mul, pow, sub, truediv

import aiohttp
import discord
import mysql
import PIL
import pytz
import requests
import urllib3
import youtube_dl
from discord import Guild, Intents, Member
from discord.ext import commands, tasks
from discord.ext.commands import *
from discord.utils import get
from discord.voice_client import VoiceClient
from mysql import connector
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

operators = {
    '+': add,
    '-': sub,
    '*': mul,
    '/': truediv,
    ':': truediv

}
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from xml.etree import cElementTree

from packages.all import *
from packages.p_mysql import *
client=discord.Client


class WELCOME(commands.Cog):
    def __init__(self, client):
        self.client = client   
    
    
    @commands.command()
    @commands.cooldown(1, 300, commands.BucketType.user)
    
    async def wcset(self, ctx):
        await self.client.wait_until_ready()
        if permissions.has_admin:
            def check(message):
                return message.author == ctx.author and message.channel == ctx.channel
            try:
                embed = discord.Embed(title=f'Welcome - setup',
                                      description=f'Bitte gebe eine Channel ID an oder erwähne einen Channel, den du als Willkommenschannel verwenden möchtest.',
                                      color=0xffc585)
                await ctx.send(embed=embed)
                msg = await self.client.wait_for('message', check=check, timeout=60)
                channelid = msg.content.replace('#', '').replace('<', '').replace('>', '')
                channel = self.client.get_channel(int(channelid))
                if not channel:
                    return await utils.send_error(ctx=ctx,client=self.client,desc=f'Du musst einen existierenden Channel angeben!')
                embed = discord.Embed(title=f'Welcome - setup',
                                      description=f'Bitte habe etwas geduld.',
                                      color=0xffc585)
                message = await ctx.send(embed=embed)
                sql = f"INSERT INTO pinto.welcomesetup(guildid, channelid) VALUES (%s, %s, %s)"  
                val = (f"{ctx.guild.id}", f"{channel.id}")
                try:
                    cur.execute(sql, val)
                    embed = discord.Embed(title=f'Welcome - setup',
                                          description=f'Der Willkommenschannel wurde in {channel.mention} gesetzt. Die neuen User werden in {channel.mention} begrüßt.',
                                          color=0xffc585)
                    await message.edit(embed=embed)
                except:
                    cur.execute(f"UPDATE pinto.welcomesetup SET channelid = '{channel.id}' WHERE guildid = '{ctx.guild.id}'")
                    embed = discord.Embed(title=f'Welcome - setup',
                                          description=f'Der Willkommenschannel wurde in {channel.mention} gesetzt. Die neuen User werden in {channel.mention} begrüßt.',
                                          color=0xffc585)
                    await message.edit(embed=embed)
            except:
                return await utils.send_error(ctx=ctx, client=self.client, desc=f'Bitte überprüfe deine Eingaben!')
        else:
            await permissions.no_perms(ctx=ctx)



def setup(client):
    client.add_cog(WELCOME(client))
